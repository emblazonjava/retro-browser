
class Error400Controller(object):
    """
    Class to implement 400 errors
    """

    def index(self):
        return {}
