
class Error500Controller(object):
    """
    Class to implement 500 errors
    """

    def index(self):
        return {}
