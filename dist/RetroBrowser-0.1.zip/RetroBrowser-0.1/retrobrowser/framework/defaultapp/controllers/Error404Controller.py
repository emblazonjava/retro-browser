
class Error404Controller(object):
    """
    Class to implement 404 errors
    """

    def index(self):
        return {}